// A tuple class to facilitate the storage of coordinates

public class Tuple {
	public int x;
	public int y;
	
	public Tuple(int x, int y) {
		this.x = x;
		this.y = y;
	}
}
